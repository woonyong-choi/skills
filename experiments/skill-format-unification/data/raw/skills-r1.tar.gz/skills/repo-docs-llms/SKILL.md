---
name: repo-docs-llms
description: "저장소 루트 llms.txt와 llms-full.txt를 만들거나 갱신할 때 사용. llmstxt.org 형식, README와 docs/README.md에서 내용을 옮기는 규칙, 두 파일을 만드는 gen_llms 함수"
---

# Repo Docs Llms

- 저장소에 같은 역할의 규칙이나 스킬이 있으면 그것 우선
- 기반: repo-docs 먼저 적용. 이 스킬 범위: 루트 `llms.txt`, `llms-full.txt`의 형식과 생성

- 두 파일은 `gen_llms` 함수로만 생성, 손 작성 금지
- 원본: 루트 `README.md`와 `docs/README.md`. 원본에 없는 글자 추가 금지

## 파일

| 파일 | 내용 | 만드는 조건 |
|---|---|---|
| `llms.txt` | 이름, 한 줄 소개, 소개 문단, 문서 링크 목록 | `docs/README.md` 존재 |
| `llms-full.txt` | `README.md`와 `docs/README.md` 표의 문서 본문을 표 순서대로 이은 것 | `llms.txt`와 동일 |

## llms.txt 형식

llmstxt.org 형식(2026-09-30 확인)

```text
# {이름}

> {한 줄 소개}

{소개 문단}

## 문서

- [{문서 제목}]({URL}): {내용}

## Optional

- [{문서 제목}]({URL}): {내용}
```

| 자리 | 원본 |
|---|---|
| 이름 | README `#` 제목 |
| 한 줄 소개 | README 제목 다음 첫 문단 |
| 소개 문단 | README 둘째 문단 |
| 문서 | `docs/README.md` 표의 행 중 `experiments/`, `decisions/`가 아닌 행. 같은 순서 |
| Optional | `docs/README.md` 표의 `experiments/`, `decisions/` 행과 `CHANGELOG.md`(링크 글자는 그 파일의 `#` 제목, 설명 없음) |
| URL | `https://raw.githubusercontent.com/{소유자}/{저장소}/main/docs/{파일}`. 원문 마크다운 주소 |

- `## Optional`: 형식이 정한 영어 제목 그대로, 건너뛰어도 되는 문서라는 뜻

## 만들기

실행 위치: 저장소 루트

````sh
gen_llms() {
  python3 - <<'EOF'
import re, subprocess
remote = subprocess.run(["git", "remote", "get-url", "origin"], capture_output=True, text=True, check=True).stdout.strip()
m = re.search(r"github\.com[:/](.+?)(\.git)?$", remote)
if not m:
    raise SystemExit("origin이 GitHub 저장소가 아님: " + remote)
repo = m.group(1)
raw = f"https://raw.githubusercontent.com/{repo}/main/"
readme = open("README.md", encoding="utf-8").read()
blocks = [b.strip() for b in re.split(r"\n\s*\n", readme) if b.strip()]
name = blocks[0].lstrip("# ").strip()
tagline, intro = blocks[1], blocks[2]
rows = []
for line in open("docs/README.md", encoding="utf-8"):
    m = re.match(r"\| \[(.+?)\]\((.+?)\) \| (.+?) \|$", line.rstrip("\n"))
    if m:
        rows.append(m.groups())
main = [r for r in rows if not r[1].startswith(("experiments/", "decisions/"))]
opt = [r for r in rows if r[1].startswith(("experiments/", "decisions/"))]
out = [f"# {name}", "", f"> {tagline}", "", intro, "", "## 문서", ""]
out += [f"- [{t}]({raw}docs/{f}): {d}" for t, f, d in main]
extra = [f"- [{t}]({raw}docs/{f}): {d}" for t, f, d in opt]
try:
    title = open("CHANGELOG.md", encoding="utf-8").readline().lstrip("# ").strip()
    extra.append(f"- [{title}]({raw}CHANGELOG.md)")
except FileNotFoundError:
    pass
if extra:
    out += ["", "## Optional", ""] + extra
open("llms.txt", "w", encoding="utf-8").write("\n".join(out) + "\n")
parts = ["README.md"] + ["docs/" + f for _, f, _ in rows]
full = []
for p in parts:
    full.append(f"<!-- {p} -->\n\n" + open(p, encoding="utf-8").read().strip() + "\n")
open("llms-full.txt", "w", encoding="utf-8").write("\n".join(full))
EOF
}
````

- 실행 뒤 확인: `llms.txt` 링크 수와 `docs/README.md` 표 행 수 일치(`CHANGELOG.md` 행 제외)
- `llms-full.txt`의 파일 구분 줄 `<!-- {경로} -->`: 형식의 일부, repo-docs 검사 대상 제외

## 갱신

- README, `docs/README.md` 수정 PR: `gen_llms` 재실행, 두 파일 함께 커밋(git-pull-request)
- `docs/README.md` 표의 문서 본문 수정 PR: `llms-full.txt`도 재생성
