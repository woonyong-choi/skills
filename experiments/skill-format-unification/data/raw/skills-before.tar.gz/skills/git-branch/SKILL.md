---
name: git-branch
description: "Git 브랜치 생성·이름 짓기, PR 생성·머지, main 반영, 병렬 에이전트 작업 분배 시 사용. main + 짧은 작업 브랜치, squash merge"
---

# Git Branch

- 작업 중인 프로젝트에 브랜치 컨벤션이나 같은 역할의 스킬이 있으면 그것을 따름
- 없으면 이 스킬이 다른 규칙보다 우선
- 커밋 메시지·PR 제목·squash 메시지 형식은 git-commit 스킬을 따름

## 구조

- 영구 브랜치는 `main` 하나. 나머지는 짧은 작업 브랜치
- `main`은 항상 빌드·테스트 통과 상태
- `main` 직접 commit·push 금지. PR로만 반영

## 혼자·팀

기준: 저장소 쓰기 권한이 있는 사람 수. 1명이면 혼자, 2명 이상이면 팀. AI 에이전트는 세지 않음.

| 항목 | 혼자 | 팀 |
|---|---|---|
| `main` 직접 push | 금지 | 금지 |
| PR | 필수 | 필수 |
| 머지 전 리뷰 승인 | 없음 | 작성자가 아닌 사람 1명 |
| 검증 | CI 있으면 CI 통과, 없으면 로컬 빌드·테스트·포맷·린트 통과 | 같음 |

## 작업 단위

이슈 하나 = 브랜치 하나 = PR 하나 = 작업 주체 하나.

- 모든 작업에 이슈 번호. 이슈가 없으면 먼저 만듦. 만들 수 없으면 중단하고 보고
- 작업 주체: 사람은 이슈 담당자(assignee). 같은 계정을 쓰는 AI 에이전트는 그 브랜치를 만든 에이전트
- 주체가 아니면 그 브랜치에서 작업 금지
- 같은 이슈로 열린 브랜치 둘 이상 금지
- 예외: `experiment` 이슈는 PR 둘. 사전 등록 PR을 머지하고 브랜치를 지운 뒤 결과 PR 브랜치를 만든다
- 다른 이슈의 작업을 브랜치에 섞지 않음. 서로 독립된 변경이면 이슈부터 분리
- 작업이 크면 브랜치가 아니라 이슈를 하위 이슈로 나눔. 하위 이슈마다 브랜치 하나

## 이름

`type/이슈번호-scope-설명`

- type·scope: git-commit 스킬과 같은 단어
- 설명: 영어 소문자 kebab-case, 2~5단어

| 예 | 뜻 |
|---|---|
| `feat/12-engine-rpc-server` | 12번 이슈, engine에 RPC 서버 추가 |
| `fix/31-tui-live-area-height` | 31번 이슈, tui 실행 영역 높이 버그 |
| `docs/40-readme-install` | 40번 이슈, README 설치 방법 |
| `release/v0.1` | 릴리스 브랜치 (예외 형식) |

## 시작 전 확인

1. `git fetch origin --prune`
2. 같은 이슈 번호 브랜치: `git branch -a --list "*/{번호}-*"`
3. 같은 이슈 번호 열린 PR: `gh pr list --state open --search "{번호} in:title,body"`
4. 사용 중인 worktree: `git worktree list`
5. 이슈 담당자: 비어 있으면 자기 계정 지정, 다른 사람이면 중단

- 2~4에서 같은 이슈가 나오면 새 브랜치 금지
- 사용자가 그 브랜치를 이어서 하라고 지정했으면 이어서 작업, 아니면 중단하고 보고

## 작업 중

- 최신 `main`에서 분기: `git switch -c {브랜치} origin/main`
- 병렬 에이전트는 에이전트마다 worktree 하나: `git worktree add ../{폴더} -b {브랜치} origin/main`
- 자기 작업 브랜치 push는 허용. 다른 주체의 브랜치에 commit·push 금지
- `main` 변경 반영은 `git merge origin/main`. 요청 없는 rebase·force push 금지

## PR

- 제목: git-commit 스킬 첫 줄 형식. 여러 모듈이면 가장 많이 바뀐 모듈, 저장소 전반이면 `repo`
- 본문 첫 줄: `Closes: #{번호}`. `experiment` 이슈의 사전 등록 PR만 `Refs: #{번호}`
- 본문: git-pull-request 스킬의 틀
- 머지 전: `git merge origin/main` 후 빌드·테스트·포맷·린트 재실행
- 본문에 AI 흔적 금지

## 머지

- squash merge만
- squash 메시지: 첫 줄은 PR 제목, 본문·꼬리말은 git-commit 스킬 규칙, 꼬리말에 PR 본문 첫 줄과 같은 `Closes: #{번호}` 또는 `Refs: #{번호}`
- GitHub가 자동으로 붙이는 커밋 목록·`Co-Authored-By` 줄은 지움
- AI는 PR 생성까지. 머지는 요청이 있을 때만
- 머지 후 자기 브랜치 삭제: 원격, 로컬, worktree

## 정리

- 브랜치 생성 후 7일 넘게 머지 안 되면 사용자에게 보고
- 이슈가 취소되면 PR 닫고 브랜치 삭제

## 릴리스

- `main`에 태그 `v{major}.{minor}.{patch}`. 요청이 있을 때만
- 지난 버전을 고쳐야 할 때만 해당 태그에서 `release/v{major}.{minor}` 생성
- 수정은 `main`에 먼저 PR로 반영 → 원 이슈를 참조하는 백포트 이슈를 새로 만들고 그 이슈 브랜치를 `release/*`에서 분기해 PR → 머지 후 새 태그
- 급한 수정도 `fix/` 브랜치 + PR. 예외 없음

## 금지

- `main`·`release/*` 직접 commit·push
- 같은 이슈 브랜치 중복 생성, 다른 이슈 작업 섞기
- 다른 주체의 브랜치 작업
- 요청 없는 rebase·force push
- 요청 없는 머지·태그·브랜치 보호 설정 변경
