---
name: code-style-kotlin
description: "Kotlin(JVM 서버·CLI) 코드 작성·리뷰·리팩터링 시 code-style과 함께 사용. 이름 형식, 에러 처리, 로그(SLF4J), 공개 범위·KDoc, 파일·클래스 구성, 테스트, detekt·ktlint 설정과 검사 명령"
---

# Code Style: Kotlin

- code-style을 먼저 읽고 함께 적용. code-style이 언어 공통 규칙의 정본이고, 이 스킬은 code-style이 언어에 맡긴 부분만 Kotlin으로 정함
- 이 스킬과 code-style이 다르면 code-style을 따름
- 작업 중인 프로젝트에 Kotlin 코드 스타일 컨벤션이나 같은 역할의 스킬이 있으면 그것을 따름
- 없으면 code-style과 이 스킬이 다른 규칙보다 우선
- 대소문자 표기는 Kotlin 공식 코딩 컨벤션, 포맷은 ktlint
- 대상은 JVM 서버·CLI. Android는 다루지 않음

## 이름

| 대상 | 규칙 | 예 |
|---|---|---|
| 접근자 | 프로퍼티로. `getX()`·`setX()` 함수 금지 | `session.name` |
| 읽기 전용 공개 | `private set`, 또는 비공개 백킹 프로퍼티 `_이름` | `private val _items`, `val items: List<Item> get() = _items` |
| 생성 | 생성자. 팩토리는 companion object에 용도가 드러나는 이름 | `Config.fromFile(path)`, `Point.fromPolar(a, r)` |
| 변환 | `toX()` 새 객체, `asX()` 원본을 감싼 뷰 | `toList()`, `asSequence()` |
| 실패하면 null | `OrNull` 접미사 | `findOrNull(id)` |
| 상수 | `const val`, SCREAMING_SNAKE_CASE | `const val MAX_RETRY = 3` |
| 약어 | 두 글자는 모두 대문자, 세 글자 이상은 첫 글자만 | `IOStream`, `HttpClient` |
| 단위 | `kotlin.time.Duration` 우선 | `timeout: Duration` |

- 계산이 싸고 예외가 없고 상태가 같으면 같은 값을 주는 것은 함수 대신 프로퍼티

## 선언 순서

파일:

1. `@file:` 애노테이션
2. `package`
3. `import`. ktlint 순서(사전순 한 그룹, `java`·`javax`·`kotlin`은 끝, 별칭은 맨 끝). 와일드카드 금지
4. 최상위 상수·logger
5. 타입. 공개 먼저
6. 최상위 함수·확장 함수

클래스 (Kotlin 공식 순서):

1. 프로퍼티와 `init` 블록. `val` → `var`, 같은 안에서 공개 → 비공개
2. 보조 생성자
3. 메서드. code-style 타입 순서의 6~10 (프로퍼티·접근자 → 생명주기 → 공개 → 비공개 헬퍼 → 검증)
4. companion object. 상수와 팩토리는 여기에 두고 클래스 맨 끝에 둠

## 에러와 로그

| 경우 | 처리 |
|---|---|
| 호출하는 쪽이 경우별로 처리할 실패 | `sealed interface` 결과 타입 반환 |
| 실패 이유가 하나뿐인 실패 | `null` 반환, 함수 이름에 `OrNull` |
| 복구하지 않고 위로 올릴 실패 (I/O 등) | 예외. 실행 앱 최상위에서 한 번 처리 |
| 코드에 버그가 없으면 일어날 수 없는 경우 | 인자는 `require(조건) { "<이유>" }`, 상태는 `check(조건) { "<이유>" }`, 도달 불가는 `error("<이유>")` |
| 테스트 | `!!`·`assertFailsWith` 허용 |

- 테스트 밖에서 `!!`, `TODO()` 금지
- 예외는 역할이 드러나는 자체 예외 클래스로. `Exception`·`RuntimeException`을 직접 던지지 않음
- 원인 보존: `throw ConfigException("Failed to read config", cause = e)`
- `catch (e: Exception)`은 실행 앱 최상위 처리기에서만
- suspend 함수 안에서 `runCatching` 금지. `CancellationException`을 잡으면 다시 던짐
- 에러·로그 메시지는 대문자로 시작, 마침표 없음: `Failed to read config file`
- 무시하는 예외는 이유를 주석으로 남김

로그:

| 라이브러리 | 쓰는 곳 | 역할 |
|---|---|---|
| `org.slf4j:slf4j-api` | 모든 모듈 | 로그 기록 |
| `ch.qos.logback:logback-classic` | 실행 앱 모듈 | 로그 출력 설정 |

- 저장소에 이미 정한 다른 라이브러리가 있으면 그것을 따름
- 라이브러리 모듈에 `logback-classic` 의존성 금지
- logger는 파일 최상위 `private val logger = LoggerFactory.getLogger(Session::class.java)`
- 값은 문자열 연결 대신 자리표시자로: `logger.info("Session started: {}", sessionId)`. 문자열 템플릿(`"$x"`) 금지
- 구조화 값은 `logger.atInfo().addKeyValue("sessionId", id).log("Session started")`
- 세션·요청 단위 문맥은 MDC. 코루틴에서는 `kotlinx-coroutines-slf4j`의 `MDCContext()`
- CLI 도구는 logback 출력 대상을 stderr로. stdout은 프로그램 결과에만

## 공개 범위와 주석

- 기본값이 `public`이므로 공개 범위를 항상 명시. 비공개 → `internal` → `public` 순서로 필요한 만큼만 넓힘. `protected`는 상속용에만
- 라이브러리 모듈은 `kotlin { explicitApi() }`로 공개 범위·반환 타입 명시를 강제
- 필드 접근은 프로퍼티로. 검증 규칙 없는 단순 데이터 묶음은 `data class`의 공개 `val`
- 공개 항목은 KDoc(`/** */`) 필수. 첫 문장은 한 줄 요약. 매개변수·반환값은 `@param`·`@return` 대신 본문에서 `[이름]`으로 언급
- 던지는 예외는 `@throws`

## 테스트

- JUnit 5와 `kotlin.test` 단언
- 위치: `src/test/kotlin`, 대상과 같은 패키지. 클래스 이름은 `<대상>Test`
- 이름: `parse_emptyInput_throwsException` (테스트 코드에서만 밑줄 허용)

## 린트 설정

`build.gradle.kts`:

```kotlin
plugins {
    id("io.gitlab.arturbosch.detekt") version "1.23.8"
    id("org.jlleitschuh.gradle.ktlint") version "14.2.0"
}

kotlin {
    explicitApi() // 라이브러리 모듈만
    compilerOptions {
        allWarningsAsErrors = true
    }
}

detekt {
    buildUponDefaultConfig = true
    config.setFrom("config/detekt.yml")
}
```

`config/detekt.yml`:

```yaml
complexity:
  LongMethod:
    threshold: 103
  LongParameterList:
    functionThreshold: 8
    constructorThreshold: 8
  NestedBlockDepth:
    threshold: 4
  ComplexCondition:
    threshold: 5
  CognitiveComplexMethod:
    active: true
    threshold: 16
  CyclomaticComplexMethod:
    active: false
style:
  ReturnCount:
    excludeGuardClauses: true
exceptions:
  NotImplementedDeclaration:
    active: true
```

- detekt threshold는 이 값 이상이면 경고 → code-style 절대 최대 + 1
- detekt 함수 길이는 선언 줄과 닫는 괄호도 셈 → 본문 100줄 + 2 + 1 = 103
- `ComplexCondition`은 조건 개수를 셈 → `&&`·`||` 3개 = 조건 4개, 5개부터 경고
- `!!` 검사(`UnsafeCallOnNullableType`)는 타입 정보가 필요해 `detektMain`·`detektTest`에서만 동작
- 인지 복잡도는 detekt 점수를 기준으로 삼음
- detekt·ktlint가 못 잡는 것은 직접 확인: 이름, 비교 순서, bool 매개변수, 파일 길이, 선언 순서, 로그 레벨

## 검사 명령

경고도 실패로 봄.

```
./gradlew ktlintCheck detektMain detektTest test
```
